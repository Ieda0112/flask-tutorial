from flask import (
    Blueprint, flash, g, redirect, render_template, request, url_for
)
from werkzeug.exceptions import abort

from flaskr.auth import login_required
from flaskr.db import get_db

#auth.pyと違ってurl_prefixがない→ブログがメイン機能なのでつけないのが理に適っている
bp = Blueprint('blog', __name__)

#投稿一覧を表示する
@bp.route('/')
def index():
    db = get_db()
    #executeの引数としてSQLクエリを入れている
    posts = db.execute(
        #投稿のID、タイトル、本文、作成日時(created)、投稿者のID、投稿者の名前を取得
        'SELECT p.id, title, body, created, author_id, username'
        #postテーブルpとuserテーブルuから、pの投稿者IDとuのIDを一致させる
        ' FROM post p JOIN user u ON p.author_id = u.id'
        #作成日時(created)で降順に並び替え、最新が一番上に来る
        ' ORDER BY created DESC'
    ).fetchall()#クエリの結果を全て取得
    #取得した全てをレンダーする
    return render_template('blog/index.html', posts=posts)

#新しい投稿を追加する　auth.pyのregisterに似てる
@bp.route('/create', methods = ('GET', 'POST'))
@login_required #ログインしているか確認
def create():
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        error = None

        if not title:
            error = 'Title is required.'

        if error is not None:
            flash(error)
        else:
            db = get_db()
            db.execute(
                #postテーブルに新たなtitle,body,author_idを挿入する
                'INSERT INTO post (title, body, author_id)'
                #プレースホルダ、インジェクション対策
                ' VALUES (?, ?, ?)',
                #上で定義したtitle,bodyと今ログインしているユーザのIDを入れる
                (title, body, g.user['id'])
            )
            db.commit()#変更を確定させて保存
            return redirect(url_for('blog.index'))#blog.indexのページへリダイレクト
    
    return render_template('blog/create.html')

#投稿の削除、修正のためにユーザーとポスト作成者が一致するか確認する関数
def get_post(id, check_author=True):
    post = get_db().execute(
        'SELECT p.id, title, body, created, author_id, username'
        ' FROM post p JOIN user u ON p.author_id = u.id'
        #p.idが?(今回は変数id)と一致するものを取得
        ' WHERE p.id = ?',
        (id,)
    ).fetchone()#クエリ結果の最初の１行を取得

    if post is None: #そもそも投稿がないとき
        abort(404, f"Post id {id} doesn't exist.")

     #投稿者とユーザのIDが一致しない時
    if check_author and post['author_id'] != g.user['id']:
        abort(403)
    #abort(404)はNot Found abort(403)はForbiddenのエラーを表示する
    return post

#投稿を修正して上書きする
#入力されたIDをURLに組み込んでいる
@bp.route('/<int:id>/update', methods=('GET', 'POST'))
@login_required
def update(id):
    post = get_post(id)

    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        error = None

        if not title:
            error = 'Title is required.'
        
        if error is not None:
            flash(error)
        else:
            db = get_db()
            db.execute(
                #postテーブルのtitle,bodyを新しい値を設定(SET)して、更新(UPDATE)する
                'UPDATE post SET title = ?, body = ?'
                ' WHERE id = ?',#どこを更新するかをidで指定
                (title, body, id)
            )
            db.commit()
            return redirect(url_for('blog.index'))
    
    return render_template('blog/update.html', post=post)

#投稿の削除
@bp.route('/<int:id>/delete', methods=('POST',))
@login_required
def delete(id):
    get_post(id)
    db = get_db()
    #postテーブルから削除する、どこを削除するかはidで指定
    db.execute('DELETE FROM post WHERE id = ?',(id,))
    db.commit()
    return redirect(url_for('blog.index'))