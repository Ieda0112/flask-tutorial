import functools

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash

from flaskr.db import get_db

#名前がauth、import_nameが__name__(モジュールの名前)、
#関連づけられるもの全てのURL先頭に/authがつくBlueprintを宣言
bp = Blueprint('auth', __name__, url_prefix='/auth')

#登録機能
@bp.route('/register', methods=('GET', 'POST'))
def register():
    if request.method == 'POST':    #フォームが送られてきた時の処理
        #入力されたusernameとpassword
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        error = None

        #username, passwordどちらも入力されているか確認
        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'

        #入力されたフォームをデータベースに挿入する
        if error is None:
            try:
                #プレースホルダの？でインジェクション攻撃に対応、パスワードはハッシュ値で保存
                db.execute(
                    "INSERT INTO user (username, password) VALUES (?, ?)",
                    (username, generate_password_hash(password, method='pbkdf2:sha256')),
                )#macOSの関係でハッシュ関数をsha256に変更
                
                db.commit()
            except db.IntegrityError:
                #usernameはUnique(schema.sql参照)なので被りがあるとエラー
                error = f"User {username} is already registered."
            else:
                #保存されたらログインページにリダイレクト
                return redirect(url_for("auth.login"))

        #レンダリング時の
        flash(error)

    return render_template('auth/register.html')

@bp.route('/login', methods=('GET', 'POST'))
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        error = None
        user = db.execute(
            'SELECT * FROM user WHERE username = ?', (username,)
        ).fetchone()    #クエリから１行だけ返す

        #username, passwordどちらも一致しているか確認
        if user is None:
            error = 'Incorrect username.'
        elif not check_password_hash(user['password'], password):
        #user['password]と同じハッシュ関数で入力したpasswordを確認
            error = 'Incorrect password.'
        #どちらもerrorなく通れば認証完了、ログイン成功

        if error is None:
            #辞書型のsessionに認証されたIDが保存される、データはCookieに保存
            session.clear()
            session['user_id'] = user['id']
            return redirect('/') #(url_for('index'))がなぜか使えなかったので直接('/')

        flash(error)

    return render_template('auth/login.html')

#ログインで保存されたIDを後続のリクエストでも利用できるようになる
#要求されたURLに関わらずユーザーIDがsessionに格納されているかを確認
@bp.before_app_request
def load_logged_in_user():
    user_id = session.get('user_id')

    if user_id is None:
        g.user = None
    else:
        g.user = get_db().execute(
            'SELECT * FROM user WHERE id = ?', (user_id,)
        ).fetchone()

#ログアウト時はsessionからIDを消去
@bp.route('/logout')
def logout():
    session.clear()
    return redirect('/') #(url_for('index'))がなぜか使えなかったので直接('/')

def login_required(view):
    @functools.wraps(view)
    #１つのビューを丸々包んで、userが読み込まれているか確認する
    def wrapped_view(**kwargs):
        if g.user is None:
            #userが読み込めなければログインページへ飛ばす
            return redirect(url_for('auth.login'))
        
        return view(**kwargs)
    
    return wrapped_view

#いくつかのurl_forでauth.が付いているが(auth.loginのように)これはbpの名前がauthだから
#このことが、ブループリントでまとまっているということ